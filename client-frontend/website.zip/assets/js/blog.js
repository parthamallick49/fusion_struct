// assets/js/blog.js
const API_BASE = 'https://backend.fusionstructengineering.com';

async function fetchBlogs() {
  try {
    const response = await fetch(`${API_BASE}/api/blogs`);
    if (!response.ok) throw new Error(`Failed to fetch blogs: ${response.status}`);
    const data = await response.json();
    return data;
  } catch (error) {
    console.error(error);
    return [];
  }
}

document.addEventListener('DOMContentLoaded', async () => {
  const blogContainer = document.getElementById('blog-container');
  if (!blogContainer) return console.error('blog-container element not found');

  const blogs = await fetchBlogs();

  if (!blogs.length) {
    blogContainer.innerHTML = '<p style="text-align:center;">No blogs available at the moment.</p>';
    return;
  }

  blogContainer.innerHTML = blogs.map(blog => {
    const imageUrl = blog.image.length ? `${API_BASE}${blog.image[0]}` : '/assets/images/placeholder.jpg';
    const createdDate = new Date(blog.created_at).toLocaleDateString();
    return `
      <div class="blog-card">
        <img src="${imageUrl}" alt="${blog.title}">
        <h3>${blog.title}</h3>
        <p>${blog.description}</p>
        <span>${createdDate}</span>
      </div>
    `;
  }).join('');
});

export { fetchBlogs };
